Changelog
=========

Release 2.2.4
-------------

https://github.com/CakeDC/recaptcha/tree/2.2.4

 * [f8459df](https://github.com/CakeDC/recaptcha/commit/f8459df) Formatting some code in Setup.md and updating semver
 * [c2c88a8](https://github.com/CakeDC/recaptcha/commit/c2c88a8) Fixing the installation instructions

Release 2.2.3
-------------

https://github.com/CakeDC/recaptcha/tree/2.2.3

 * [ad72132](https://github.com/CakeDC/recaptcha/commit/ad72132) Adding semver
 * [c968276](https://github.com/CakeDC/recaptcha/commit/c968276) Naming a few files uppercased to refelect the plugin standard.
 * [8f5d6c0](https://github.com/CakeDC/recaptcha/commit/8f5d6c0) Fixing the headline of the readme.md
 * [74047b7](https://github.com/CakeDC/recaptcha/commit/74047b7) Working on updating the plugin to the new plugin standard
 * [741cc11](https://github.com/CakeDC/recaptcha/commit/741cc11) Use strict comparison
 * [e3344bd](https://github.com/CakeDC/recaptcha/commit/e3344bd) Cs fixes
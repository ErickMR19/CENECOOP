Home
====

The **Recaptcha** plugin for CakePHP provides spam protection in an easy use helper.

Requirements
------------

* CakePHP 2.5+
* PHP 5.2.8+

Documentation
-------------

* [Installation](Documentation/Installation.md)
* [Setup](Documentation/Setup.md)

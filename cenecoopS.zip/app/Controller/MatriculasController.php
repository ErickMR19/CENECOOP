<?php
class MatriculasController extends AppController {

	public function index() {
		$this->requieredAdmin();
        $this->set('matriculas', $this->Matricula->find('all'));
    }

	public function add() {
		$this->requieredAdmin();

		$usuario = $this->Auth->user();
		$cedula = $usuario['cedula'];

		$grupos = $this->Matricula->query('SELECT g.CodCurso,g.NumGrupo,g.id,g.cupo FROM grupos g WHERE g.id not in (SELECT m.cod_grupo from matriculas m)'
                                            );

		$gruposf = $this->Matricula->query('SELECT DISTINCT ma.cod_curso, gr.NumGrupo, gr.NumEstudiantes from matriculas ma, grupos gr where ma.cod_grupo = gr.id '
                                            );

		$this->set('grupos', $grupos); // Carga los cursos pre-matriculados en la vista
		$this->set('gruposf', $gruposf); // Carga los cursos finalizados en la vista
    }

	public function FinalizarMatricula($cod_curso,$cod_grupo,$cupo){
		$this->requieredAdmin();
		if ( $this->request->is(array('post', 'put')) ) {
			$this->Matricula->query( " UPDATE matricula_temp SET cod_grupo= '$cod_grupo' WHERE cod_curso = '$cod_curso'" );
			echo "INSERT INTO `matriculas`(`cedula_est`,`cod_grupo`,`cod_curso`,`fecha_matricula`,`pago`)
									(
										SELECT `cedula_est`,`cod_grupo`,`cod_curso`,`fecha_matricula`,`cooperativista`
										FROM `matricula_temp`
										WHERE `cod_curso` = '$cod_curso'
										ORDER BY `cooperativista` DESC ,`fecha_matricula`
										LIMIT $cupo
									)";
			$this->Matricula->query( "INSERT INTO `matriculas`(`cedula_est`,`cod_grupo`,`cod_curso`,`fecha_matricula`,`pago`)
									(
										SELECT `cedula_est`,`cod_grupo`,`cod_curso`,`fecha_matricula`,`cooperativista`
										FROM `matricula_temp`
										WHERE `cod_curso` = '$cod_curso'
										ORDER BY `cooperativista` DESC ,`fecha_matricula`
										LIMIT $cupo
									)"
									);

			$deletes = $this->Matricula->query( "
				SELECT m.id
				FROM matricula_temp m
				WHERE m.cod_curso = '$cod_curso'
				ORDER BY cooperativista DESC ,fecha_matricula
				LIMIT $cupo "
			);

			foreach ($deletes as $delete):
			$this->Matricula->query( " 	DELETE FROM `matricula_temp`
									    WHERE `id` =  '{$delete['m']['id']}' "
									);
			endforeach;

			$cantidadAlumnos = count($delete) +1;

			$this->Matricula->query( " UPDATE grupos set NumEstudiantes = '$cantidadAlumnos' " );

			if(empty($deletes)){$this->Session->setFlash(__('Nadie ha pre-matriculado este curso.'));}
			else{$this->Session->setFlash(__('Curso Finalizado.'));}

			return $this->redirect(array('action' => 'add'));
		}

	}

	public function export() {
		$this->requieredAdmin();
		$this->response->download("export.csv");
		$_header = array('username', 'firstname', 'lastname', 'email');
		$this->set('header',$_header);

			//Join de personas con matricula, y luego con users
		$data = $this->Matricula->query('SELECT u.username, p.nombre, p.apellido1
									FROM
									matriculas AS m
									INNER JOIN personas AS p
									ON (m.cedula_est = p.id)
									INNER JOIN users AS u
									ON (m.cedula_est = u.cedula)
									GROUP BY u.username, p.nombre, p.apellido1, u.username'
									);
		$this->set('data',$data);
		$this->layout = 'ajax';
		return;
	}

}

?>

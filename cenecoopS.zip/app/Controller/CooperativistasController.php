<?php

class CooperativistasController extends AppController {
	public $helpers = array('Html', 'Form', 'Session');
    public $components = array('Session','Paginator');

    public function index() {
		$this->requieredStudent();
        $this->set('title_for_layout', 'Lista de Cooperativas Asociado');
		$cedEstudiante = $this->Auth->user()['cedula'];
        $this->set('cooperativistas', $this->Cooperativista->query("SELECT c.nombre_coop NombreCoop, ct.cargo_coop Cargo FROM cooperativas c, cooperativistas ct WHERE ct.cod_cooperativa = c.id AND ct.cedula_coop = '$cedEstudiante'")

		);

    }



	public function add() {
		$this->requieredStudent();
        $lista_cooperativas = ClassRegistry::init('Cooperativas')->find('list', array('fields' => array('id', 'nombre_coop')));
		$this->set('lista_cooperativas', $lista_cooperativas); // Carga los cursos  en la vista

        if ($this->request->is(array('post','put')) ) {
            $this->Cooperativista->create();
            $this->request->data['Cooperativista']['cedula_coop'] =$this->Auth->user()['cedula'];
            if ($this->Cooperativista->save($this->request->data)) {
                $this->Session->setFlash(__('Se guardó la Cooperativa correctamente'));
                return $this->redirect(array('action' => 'index'));
            }
            $this->Session->setFlash(__('No se pudo guardar la Cooperativa'));
        }

    }


}

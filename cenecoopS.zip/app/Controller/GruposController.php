<?php
App::uses('AppController', 'Controller');

class GruposController extends AppController {


	public function index() {
        $this->set('personas', $this->Persona->find('all'));
    }

	public function beforeFilter() {
		parent::beforeFilter();
		// Allow users to register and logout.
		$this->Auth->allow('');
	}

	public function view( $cedula = null ) {

        if ( !$cedula ) {
			throw new NotFoundException(__('Lista no encontrada'));
        }

        $persona = $this->Persona->findByid( $cedula );

		if ( !$persona ) {
            throw new NotFoundException(__('Lista no encontrada'));
        }

		$this->set('post', $persona);
    }


	// Agrega un grupo
	public function add() {
		$this->requieredAdmin();

		$lista_cursos = ClassRegistry::init('Cursos')->find('list', array('fields' => array('id','nombre_cur')));
		$this->set('lista_cursos', $lista_cursos); // Carga los cursos  en la vista

		$lista_periodo = ClassRegistry::init('Periodos')->find('list', array('fields' => array('id','id')));
		$this->set('lista_periodo', $lista_periodo); // Carga los cursos  en la vista

		$lista_profes = ClassRegistry::init('Profesores')->find('list', array(
						'joins' => array(
							array(
								'table' => 'personas',
								'alias' => 'p',
								'type' => 'INNER',
								'conditions' => array(
									'p.id = profesores.id'
								)
							)
						),
						'fields' => array('p.id', 'p.nombre')
					));

		$this->set('lista_profes', $lista_profes); // Carga los cursos  en la vista

        if ($this->request->is(array('post', 'put'))) {

			$this->Grupo->create();

			//Guarda los datos del formulario en la tabla
            if ( $this->Grupo->save($this->request->data) ) {

				$this->Session->setFlash(__('Grupo guardado.'));

				// Redireciona al segundo formulario de registro de estudiante
				return $this->redirect(array('action' => 'add'));
            }
			else{
				$this->Session->setFlash(__('The user could not be saved. Please, try again.'));
			}
        }
    }

}

<?php


class Profesor extends AppModel {

    public $useTable = 'profesores';

    public $hasMany = array(
	'ProfesorImparte' => array(
		'className' => 'Imparte',
		'foreignKey' => 'cedula_prof'
		)
	);

    public $belongsTo = array(
        'PerfilDePersona' => array(
            'className' => 'Persona',
            'foreignKey' => 'id'
        )
    );

}

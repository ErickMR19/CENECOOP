<?php

class Expediente extends AppModel {

	public $useTable = 'matriculas';

	public $validate = array(

	);

}

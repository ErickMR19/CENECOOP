<?php


class Imparte extends AppModel {

    public $useTable = 'imparte';

    public $belongsTo = array(
       'ImparteCurso' => array(
           'className' => 'Curso',
           'foreignKey' => 'cod_curso'
       ),
       'ImparteProfesor'=> array(
           'className' => 'Profesor',
           'foreignKey' => 'cedula_prof'
       )
    );


    public $validate = array(
            'required' => array(
                'rule' => array('notEmpty'),
                'message' => 'Sigla del curso requerido'

		));
}

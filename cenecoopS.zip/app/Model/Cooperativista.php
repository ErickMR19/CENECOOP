<?php

App::uses('AppModel', 'Model');
class Cooperativista extends AppModel {

	var $name = 'Cooperativista';
	public $validate = array(
		'cod_cooperativa' => array(
			'required' => array(
				'rule' => array('notEmpty'),
				'message' => 'Codigo de la cooperativa requerido'
			)
		),
		'cargo_coop' => array(
			'required' => array(
				'rule' => array('notEmpty'),
				'message' => 'Cargo requerido'
			)
		)
	);

}
